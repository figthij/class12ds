/*
project name: class12ds
program: makearr
Author: Erik Bailey
Date: Nov 19, 2020
Synoposis: 
makes array
*/
package class12ds;
import java.util.Random;
public class makearr {
    public int[] arr(){
        int size=10;
        int[] a = new int[size];
        for(int i=0;i<size;i++){
            inputnum(a,i);
        }
        return a;
    }
    public static void inputnum(int[] value,int i){
        Random rnum = new Random();
        value[i]=rnum.nextInt(100);
    }
}