/*
project name: class12ds
program: createFile
Author: Erik Bailey
Date: Nov 19, 2020
Synoposis: 
creates file and writes to it
*/
package class12ds;
import java.util.*;
public class createFile {
    private Formatter x;
    public void openFile(){
        try{
            x = new Formatter("graphcoor.txt");
            System.out.println("file has been made");
        }
        catch(Exception e){
            System.out.println("I am error");
        }
    }
    public void addRecord(String a){
        x.format("%s",a);
    }
    public void closeFile(){
        x.close();
    }
}