/*
project name: class12ds
program: swap
Author: Erik Bailey
Date: Nov 19, 2020
Synoposis: 
swaps two numbers in the array
*/
package class12ds;
import java.util.Arrays;
public class swap {
    public int[] swap(int[] a, int fir, int sec, String x){
        int temp1=a[fir];
        int temp2=a[sec];
        a[sec]=temp1;
        a[fir]=temp2;
        x=x+"\n"+Arrays.toString(a);
        coor c = new coor();
        c.file(x);
        return a;
    }
}