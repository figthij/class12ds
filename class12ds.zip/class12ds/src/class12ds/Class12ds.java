/*
project name: class12ds
program:class12ds
Author: Erik Bailey
Date: Nov 19, 2020
Synoposis: 
bubble sorts and writes result to file
*/
package class12ds;
import java.util.Arrays;
public class Class12ds {
    public static void main(String[] args) {
        makearr ma=new makearr();
        pass p = new pass();
        createFile cf = new createFile();
        int[] a =ma.arr();
        String x= Arrays.toString(a);
        coor c = new coor();
        c.file(x);
        x=p.pass(a,x);
        cf.openFile();
        cf.addRecord(x);
        cf.closeFile();
    }
}
//put arrays into a file to go to python