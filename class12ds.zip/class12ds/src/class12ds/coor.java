/*
project name: class12ds
program: coor
Author: Erik Bailey
Date: Nov 19, 2020
Synoposis: 
keeps track of what will be sent to file
*/
package class12ds;
public class coor {
    public String total;
    public String file(String add){
        total=total+"\n"+add;
        return total;
    }
}
