/*
project name: class12ds
program: pass
Author: Erik Bailey
Date: Nov 19, 2020
Synoposis: 
goes through one pass of the array, comparing and sorting
*/
package class12ds;
import java.util.Arrays;
public class pass {
    public String pass(int[] a,String x){
        compare c = new compare();
        swap s = new swap();
        int len =a.length;
        int res=0;//used to tell if swap 
        int count=0;
        for(int i = 0; i<len-1;i++){
            res=c.comp(a, i, i+1);
            if(res==1){
                a=s.swap(a, i, i+1,x);
                x=x+"\n"+Arrays.toString(a);
                count++;
            }
        }
        if(count>0){
            return pass(a,x);
        }
        return x;
    }
}