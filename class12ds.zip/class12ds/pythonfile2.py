
"""

Name: patss
Author: Erik Bailey
Date: 06/01/2020
Synoposis: this gives pathman paths to follow

"""
import os
f= open("graphcoor.txt","r")
if f.mode =="r":
    contents = f.readlines()
    print('hi')
print(contents)

#C:\Users\Erik\Desktop\data structures\class12ds