# -*- coding: utf-8 -*-
"""
Created on Sun Nov 29 14:47:00 2020

@author: Erik
"""


import os
import patss
import ToolBox as tb

def outBound(fileName,aString):
    headerList = aString.split(',')#split things when a comma appears making a list
    fO = open(fileName, 'w')#opens filename to be able to write in
    count = 0#standard count
    for i in headerList:#for each occurence of headerlist this will loop 
        if(i==(headerList[len(headerList)-1])):#used to prevent a new line from appearing in an unneeded area
            a=i.split("\n")#a is i except without a new line at the end
            i=a[0]#removes new line from the end of i
        i = i+'-- in position:' + str(count) + '\n'#makes i the whole statement that will be printed
        count =count +1#count goes up
        fO.write(i)#writes i into the file
    fO.close()#closes the file
    
fileName = os.sys.path[-2] + "\\File001.csv"#takes the filename from patss
outBoundFileName = os.sys.path[-1] + "HeadersOut000.txt"#takes the filename from patss
theList =[]#making of the list
theList=tb.load_Text_Into_A_List(fileName, theList)#loads liist using the toolbox
for i in range(2,6):#changes the filename adding 1 to the last digit
    tag = '00'+str(i)#tag is made to be the last three digits of the file
    fileNameA = fileName.replace('001',tag)#the last three digits of the file are replaced with tag
    theList = tb.load_Text_Into_A_List(fileNameA,theList)#the text from each file is loaded into theList
for i in range(1,6):#outbound files made
    tag = '00'+str(i)#tag is made to be the last three digits of the file
    fileNameA = outBoundFileName.replace('000',tag)#the last three digits of the file are replaced with tag
    templist = theList[i-1]#allows headerstr to use a steady variabl
    #input(templist[0])#
    headerStr = templist[0]#the data that will be put in the outbound file
    outBound(fileNameA, headerStr)# goes to outbound function
    
print(len(theList))