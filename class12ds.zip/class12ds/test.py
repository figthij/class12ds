"""

Name: test
Author: Erik Bailey
Date: 12/01/2020
Synoposis: displays bargraph from file made in java

"""
import matplotlib.pyplot as plt
f= open("graphcoor.txt","r")
theList=""#making of the list
i=0
f1=f.readlines()
for x in f1:
    theList=theList +x
    i=i+1
headerList = theList.split('\n')#split things when a comma appears making a list
def changes(part,one):
    partone=headerList[part].split(',')
    s=partone[0]
    s1=""
    for i in range(1, len(s)):
        s1=s1+s[i]
    one.append(int(s1))
    for i in range(1,len(partone)-1):
        one.append(int(partone[i]))
    s=partone[len(partone)-1]
    s2=""    
    for i in range(0, len(s)-1):
        s2=s2+s[i]
    one.append(int(s2))
def graph(part):
    one=[]
    changes(part,one)
    names =[str(one[0]), str(one[1]), str(one[2]),str(one[3]), str(one[4]), str(one[5]),str(one[6]), str(one[7]), str(one[8]),str(one[9])]
    values = [one[0], one[1], one[2],one[3],one[4],one[5],one[6],one[7],one[8],one[9]]
    plt.figure(figsize=(30,6))
    plt.subplot(131)
    plt.bar(names, values)
count=0
while count<i:
    graph(count)
    count+=1
    print(count)
    plt.show()
plt.show()