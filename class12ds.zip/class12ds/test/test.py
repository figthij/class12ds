# -*- coding: utf-8 -*-
"""
Created on Fri Nov 27 14:45:25 2020

@author: Erik
"""


import matplotlib.pyplot as plt
f= open("graphcoor.txt","r")
if f.mode =="r":
    contents = f.readlines()
    print('hi')
print(contents)

#print('hi')
names =['a', 'b', 'c','d', 'e', 'f','g', 'h', 'i','j']
values = [1, 2, 3,4,5,6,7,8,9,10]
plt.figure(figsize=(15,3))
plt.subplot(131)
plt.bar(names, values)
plt.show()